function love.conf(t)
	t.title = "It Came from the Forest"
	t.version = "11.4"
	t.identity = "zooperdan.it-came-from-the-forest"
	t.appendidentity = true
	t.window.width = 1280
	t.window.height = 720
	t.console = false
	t.window.fullscreen = true
	t.window.fullscreentype = "desktop"
	t.window.fsaa = 0
	t.window.icon = "files/icon.png"
end